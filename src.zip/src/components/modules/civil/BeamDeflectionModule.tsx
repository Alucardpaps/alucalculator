'use client';

import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
    Ruler, Zap, Gauge, AlertTriangle,
    ArrowDown, Layers, Box, Info
} from 'lucide-react';
import { useI18nStore } from '@/store/i18nStore';

export default function BeamDeflectionModule() {
    const { t } = useI18nStore();

    const [inputs, setInputs] = useState({
        length: 3000, // mm
        load: 10, // kN
        modulus: 70, // GPa (Aluminum)
        inertia: 15.5, // 10^6 mm^4
        type: 'simple' as 'simple' | 'cantilever'
    });

    const results = useMemo(() => {
        const L = inputs.length;
        const F = inputs.load * 1000; // N
        const E = inputs.modulus * 1000; // N/mm^2
        const I = inputs.inertia * 1000000; // mm^4

        // Deflection formulas
        // Simple: (F * L^3) / (48 * E * I)
        // Cantilever: (F * L^3) / (3 * E * I)

        let delta = 0;
        if (inputs.type === 'simple') {
            delta = (F * Math.pow(L, 3)) / (48 * E * I);
        } else {
            delta = (F * Math.pow(L, 3)) / (3 * E * I);
        }

        const limit = L / 300;
        const isSafe = delta <= limit;

        return { delta, limit, isSafe };
    }, [inputs]);

    return (
        <div className="flex flex-col h-full bg-[#0a0e14] text-white p-6 overflow-y-auto custom-scrollbar">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                    <div className="p-3 bg-blue-500/20 rounded-2xl border border-blue-500/30 text-blue-400">
                        <Layers size={24} />
                    </div>
                    <div>
                        <h2 className="text-2xl font-black tracking-tight">{t.modules?.beamDeflection?.title || 'Beam Deflection'}</h2>
                        <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Civil Engineering • Structural Analysis</p>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Inputs */}
                <div className="lg:col-span-5 space-y-6 bg-white/[0.02] border border-white/5 p-6 rounded-[32px]">
                    <div className="flex items-center gap-2 mb-2 text-blue-400">
                        <Gauge size={16} />
                        <span className="text-[10px] font-black uppercase tracking-widest">Input Parameters</span>
                    </div>

                    {/* Beam Type Toggle */}
                    <div className="flex bg-black/40 rounded-2xl p-1 border border-white/5">
                        {(['simple', 'cantilever'] as const).map(type => (
                            <button
                                key={type}
                                onClick={() => setInputs({ ...inputs, type })}
                                className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${inputs.type === type ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/20' : 'text-gray-500 hover:text-gray-300'}`}
                            >
                                {type}
                            </button>
                        ))}
                    </div>

                    <div className="space-y-4">
                        <InputField
                            label="Beam Length (L)"
                            unit="mm"
                            value={inputs.length}
                            min={500} max={20000} step={100}
                            onChange={(v: number) => setInputs({ ...inputs, length: v })}
                            color="#3b82f6"
                        />
                        <InputField
                            label="Applied Load (F)"
                            unit="kN"
                            value={inputs.load}
                            min={0.1} max={500} step={0.5}
                            onChange={(v: number) => setInputs({ ...inputs, load: v })}
                            color="#f59e0b"
                        />
                        <InputField
                            label="Elastic Modulus (E)"
                            unit="GPa"
                            value={inputs.modulus}
                            min={10} max={300} step={1}
                            onChange={(v: number) => setInputs({ ...inputs, modulus: v })}
                            color="#10b981"
                        />
                        <InputField
                            label="Inertia (Ix)"
                            unit="10⁶ mm⁴"
                            value={inputs.inertia}
                            min={0.1} max={5000} step={0.1}
                            onChange={(v: number) => setInputs({ ...inputs, inertia: v })}
                            color="#8b5cf6"
                        />
                    </div>
                </div>

                {/* Results & Visualization */}
                <div className="lg:col-span-7 space-y-8">
                    {/* Main Result Card */}
                    <div className={`p-8 rounded-[40px] border transition-all duration-500 relative overflow-hidden ${results.isSafe ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-red-500/10 border-red-500/30 shadow-[0_0_30px_rgba(239,68,68,0.1)]'}`}>
                        <div className="relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
                            <div>
                                <div className="text-[10px] font-black uppercase tracking-[0.3em] mb-4 flex items-center gap-2" style={{ color: results.isSafe ? '#10b981' : '#ef4444' }}>
                                    <div className={`w-2 h-2 rounded-full ${results.isSafe ? 'bg-emerald-500' : 'bg-red-500 animate-pulse'}`} />
                                    {results.isSafe ? 'Structure Safe' : 'Limit Exceeded'}
                                </div>
                                <h3 className="text-8xl font-black italic tracking-tighter leading-none mb-2">
                                    {results.delta.toFixed(2)}
                                </h3>
                                <p className="text-gray-400 font-bold uppercase tracking-widest">Max Deflection (mm)</p>
                            </div>
                            <div className="flex flex-col items-end gap-2">
                                <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Allowable Limit (L/300)</span>
                                <span className="text-2xl font-mono font-black text-gray-300">{results.limit.toFixed(2)} mm</span>
                            </div>
                        </div>

                        {/* Background Decoration */}
                        <div className="absolute top-1/2 right-10 -translate-y-1/2 opacity-5 pointer-events-none">
                            <Box size={200} />
                        </div>
                    </div>

                    {/* Simple Visualization */}
                    <div className="bg-black/40 border border-white/5 rounded-[32px] p-8 aspect-[16/6] relative flex items-center justify-center">
                        <div className="absolute top-4 left-4 flex items-center gap-2 text-[10px] font-black text-gray-600 uppercase tracking-widest">
                            <Ruler size={12} /> Live Deformation Map
                        </div>

                        {/* Beam Visualization */}
                        <div className="w-[80%] h-1 bg-white/10 relative">
                            {/* Support Simple */}
                            {inputs.type === 'simple' && (
                                <>
                                    <div className="absolute -bottom-4 left-0 w-8 h-8 border-t-2 border-l-2 border-white/20 rotate-45 transform translate-x-[-50%]" />
                                    <div className="absolute -bottom-4 right-0 w-8 h-8 border-t-2 border-r-2 border-white/20 -rotate-45 transform translate-x-[50%]" />
                                </>
                            )}

                            {/* Support Cantilever */}
                            {inputs.type === 'cantilever' && (
                                <div className="absolute -top-10 -bottom-10 left-0 w-4 bg-white/5 border-r border-white/10" />
                            )}

                            {/* Deformed Beam */}
                            <motion.svg
                                className="absolute inset-x-0 -top-0 w-full h-[150px] overflow-visible pointer-events-none"
                                preserveAspectRatio="none"
                            >
                                <motion.path
                                    d={inputs.type === 'simple'
                                        ? `M 0,0 Q 50,${Math.min(results.delta * 2, 80)} 100,0`
                                        : `M 0,0 Q 50,0 100,${Math.min(results.delta * 2, 80)}`
                                    }
                                    fill="none"
                                    stroke="#3b82f6"
                                    strokeWidth="4"
                                    strokeLinecap="round"
                                    vectorEffect="non-scaling-stroke"
                                    animate={{
                                        d: inputs.type === 'simple'
                                            ? `M 0,0 Q 50,${Math.min(results.delta * 2, 80)} 100,0`
                                            : `M 0,0 Q 50,0 100,${Math.min(results.delta * 2, 80)}`
                                    }}
                                />
                                {/* Arrow */}
                                <motion.g animate={{ y: inputs.type === 'simple' ? Math.min(results.delta * 2, 80) : Math.min(results.delta * 2, 80) }}>
                                    <ArrowDown
                                        className="text-amber-500/50"
                                        size={24}
                                        x={inputs.type === 'simple' ? '45%' : '95%'}
                                        y={-30}
                                    />
                                </motion.g>
                            </motion.svg>
                        </div>
                    </div>
                </div>
            </div>

            {/* Warning Overlay if unsafe */}
            {!results.isSafe && (
                <div className="mt-8 p-4 bg-red-500/20 border border-red-500/50 rounded-2xl flex items-center gap-4 text-red-200">
                    <AlertTriangle className="shrink-0" />
                    <div>
                        <p className="text-xs font-black uppercase tracking-widest">Critical Structural Warning</p>
                        <p className="text-[10px] opacity-80 mt-1">Calculated deflection exceeds the L/300 serviceability limit. Increase section inertia or decrease span length.</p>
                    </div>
                </div>
            )}
        </div>
    );
}

function InputField({ label, unit, value, min, max, step, onChange, color }: any) {
    return (
        <div className="space-y-2">
            <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-gray-500">
                <span>{label}</span>
                <span style={{ color }}>{value} <span className="opacity-60">{unit}</span></span>
            </div>
            <input
                type="range" min={min} max={max} step={step}
                className="w-full h-1 bg-white/5 rounded-full appearance-none cursor-ew-resize hover:bg-white/10 transition-colors"
                style={{ accentColor: color }}
                value={value}
                onChange={(e) => onChange(Number(e.target.value))}
            />
        </div>
    );
}
