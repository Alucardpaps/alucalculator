import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, BrainCircuit } from 'lucide-react';
import { useOSStore } from '@/store/osStore';

interface Message {
    id: string;
    role: 'user' | 'assistant';
    content: string;
    timestamp: Date;
    isCode?: boolean;
}

export function AICopilotModule() {
    const { isChaosMode } = useOSStore();
    const [messages, setMessages] = useState<Message[]>([
        {
            id: '1',
            role: 'assistant',
            content: "AluCalc Engineering Brain initialized. I can assist with material selection, stress calculations, or workflow automation. What are we building today?",
            timestamp: new Date()
        }
    ]);
    const [inputValue, setInputValue] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const scrollRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages, isTyping]);

    const handleSend = () => {
        if (!inputValue.trim()) return;

        const userMsg: Message = {
            id: Date.now().toString(),
            role: 'user',
            content: inputValue,
            timestamp: new Date()
        };

        setMessages(prev => [...prev, userMsg]);
        setInputValue('');
        setIsTyping(true);

        // Simulate AI thinking and response
        setTimeout(() => {
            let responseContent = "Analyzing engineering parameters...";
            let isCode = false;

            const lowerInput = userMsg.content.toLowerCase();
            if (lowerInput.includes('alloy') || lowerInput.includes('aluminum')) {
                responseContent = "For aerospace applications demanding high strength-to-weight ratio, I recommend Aluminum 7075-T6. \n\nYield Strength: 503 MPa\nUltimate Tensile Strength: 572 MPa\nDensity: 2.81 g/cm³\n\nWould you like me to open the Material Science module with these parameters pre-loaded?";
            } else if (lowerInput.includes('code') || lowerInput.includes('script')) {
                responseContent = `function calculateDeflection(force, length, eModulus, inertia) {\n  // Cantilever beam point load\n  return (force * Math.pow(length, 3)) / (3 * eModulus * inertia);\n}`;
                isCode = true;
            } else if (isChaosMode) {
                responseContent = "WARNING: AVANT-GARDE LOGIC DETECTED. The optimal solution is geometric distortion. Let the structures fail gracefully to reveal their true form.";
            }

            setMessages(prev => [...prev, {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: responseContent,
                timestamp: new Date(),
                isCode
            }]);
            setIsTyping(false);
        }, 1500);
    };

    return (
        <div className="flex flex-col h-full bg-[#0a0a0a] text-cyan-50 font-sans relative overflow-hidden">
            {/* Background Effects */}
            <div className="absolute inset-0 z-0 opacity-10 pointer-events-none">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_rgba(99,102,241,0.2),_transparent_50%)]"></div>
            </div>

            {/* Header */}
            <div className="z-10 px-4 py-3 border-b flex items-center justify-between bg-black/40 backdrop-blur-md border-indigo-500/30">
                <div className="flex items-center gap-3">
                    <div className="p-1.5 bg-indigo-500/20 rounded-md">
                        <BrainCircuit className="w-5 h-5 text-indigo-400" />
                    </div>
                    <div>
                        <h2 className="text-sm font-bold tracking-wider text-indigo-100 uppercase">AluCalc Brain</h2>
                        <p className="text-[10px] font-mono text-indigo-400/80">LLM Engine v4.0.0-rc2</p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                    </span>
                    <span className="text-[10px] font-mono uppercase text-indigo-400">Online</span>
                </div>
            </div>

            {/* Message History */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 z-10 scrollbar-thin scrollbar-thumb-indigo-900/50" ref={scrollRef}>
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[85%] rounded-2xl p-3 shadow-lg ${msg.role === 'user'
                                ? 'bg-indigo-600/20 border border-indigo-500/30 text-indigo-50 rounded-tr-sm'
                                : 'bg-[#111] border border-cyan-900/30 text-cyan-100 rounded-tl-sm'
                            }`}>
                            <div className="flex items-center gap-2 mb-1.5 opacity-60">
                                {msg.role === 'user' ? <User size={12} /> : <Sparkles size={12} className="text-indigo-400" />}
                                <span className="text-[10px] font-mono uppercase">{msg.role}</span>
                                <span className="text-[9px] font-mono ml-auto">{msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                            </div>

                            {msg.isCode ? (
                                <pre className="p-3 bg-black/50 rounded border border-indigo-900/50 text-xs font-mono overflow-x-auto text-indigo-300 mt-2">
                                    <code>{msg.content}</code>
                                </pre>
                            ) : (
                                <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                            )}
                        </div>
                    </div>
                ))}

                {isTyping && (
                    <div className="flex justify-start">
                        <div className="bg-[#111] border border-cyan-900/30 rounded-2xl rounded-tl-sm p-4 shadow-lg flex items-center gap-1">
                            <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                            <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                            <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                        </div>
                    </div>
                )}
            </div>

            {/* Input Area */}
            <div className="z-10 p-4 border-t border-indigo-900/30 bg-[#0a0a0a]">
                <div className="relative flex items-center">
                    <input
                        type="text"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="Ask the engineering copilot..."
                        className="w-full bg-[#111] border border-indigo-900/50 rounded-xl py-3 pl-4 pr-12 text-sm text-indigo-100 placeholder:text-indigo-900/70 focus:outline-none focus:border-indigo-500/50 transition-colors shadow-inner"
                    />
                    <button
                        onClick={handleSend}
                        disabled={!inputValue.trim() || isTyping}
                        className="absolute right-2 p-2 rounded-lg bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500/40 hover:text-indigo-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <Send size={16} />
                    </button>
                </div>
            </div>
        </div>
    );
}
