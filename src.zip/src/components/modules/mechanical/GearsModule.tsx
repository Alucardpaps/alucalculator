"use client";
import { useState, useEffect } from "react";
import { useDriveTrainCalculator } from "@/hooks/useDriveTrainCalculator";
import { TechnicalDrawing } from "@/components/TechnicalDrawing";
import { IEC_MOTORS } from "@/data/motorData";
import { GEAR_MODULES_ISO, GEAR_MATERIALS, APPLICATION_FACTORS } from "@/data/gearsData";
import { CalculatorInput } from "@/components/CalculatorInput";
import { Canvas } from "@react-three/fiber";
import { PresentationControls, Stage } from "@react-three/drei";
import { Gear3D } from "@/components/3d/Gear3D";
import { EngineeringVisualization } from "@/components/ui/EngineeringVisualization";
import { AssumptionPanel, CalculationMetadata } from "@/components/ui/AssumptionPanel";
import { CheckCircle, AlertTriangle } from 'lucide-react';

import { StockCheck } from "../shared/StockCheck";
import { PDFGenerator } from "../shared/PDFGenerator";

export function GearsModule({ lang, dict }: { lang: string, dict: any }) {
    // ... existing hook ...
    const {
        selectedPower, setSelectedPower,
        selectedPoles, setSelectedPoles,
        motor,
        gearModule, setGearModule,
        z1, setZ1,
        z2, setZ2,
        helixAngle, setHelixAngle,
        faceWidth, setFaceWidth,
        materialName, setMaterialName,
        results,
        x1, setX1, x2, setX2,
        pinDia1, setPinDia1, pinDia2, setPinDia2,
        // YR Inputs
        loadClass, setLoadClass,
        dailyHours, setDailyHours,
        startsPerHour, setStartsPerHour,
        connectionType, setConnectionType,
    } = useDriveTrainCalculator();

    const [viewMode, setViewMode] = useState<'2D' | '3D'>('3D');

    // ... existing metadata ...
    const metadata: CalculationMetadata = {
        standardId: "ISO 6336:2019",
        standardTitle: "Calculation of load capacity of spur and helical gears",
        version: "2.1.0",
        assumptions: [
            "Operating Temp: 20°C",
            "Lubrication: Splash Oil (ISO VG 220)",
            "Quality Grade: ISO 7"
        ]
    };

    // Calculate Status
    const isSafe = results.SF_bending > 1.4 && results.SF_contact > 1.0;
    const isWarn = !isSafe && (results.SF_bending > 1.0 && results.SF_contact > 0.9);
    const status = isSafe ? 'valid' : isWarn ? 'warning' : 'invalid';

    // Derived Logic for Stock
    const da1 = gearModule * z1 + 2 * gearModule * (1 + x1);
    const da2 = gearModule * z2 + 2 * gearModule * (1 + x2);
    const requiredDia = Math.max(da1, da2) + 5;
    const requiredLen = faceWidth + 10;

    return (
        <div className="flex flex-col h-full bg-transparent text-slate-200 select-none p-6">
            {/* Toolbar - Only View Mode Toggle */}
            <div className="flex items-center gap-2 mb-6 justify-end">
                <div className="mr-auto">
                    <span className="text-[10px] font-black uppercase text-purple-500 tracking-[0.3em] bg-purple-500/10 px-3 py-1.5 rounded-full border border-purple-500/20">ISO 6336 Gearset</span>
                </div>
                <button onClick={() => setViewMode('2D')} className={`px-4 py-1.5 text-[10px] font-black tracking-widest uppercase transition-all rounded-full border ${viewMode === '2D' ? 'bg-purple-500/20 text-purple-400 border-purple-500/50' : 'bg-white/5 text-gray-500 border-white/10 hover:text-white'}`}>2D</button>
                <button onClick={() => setViewMode('3D')} className={`px-4 py-1.5 text-[10px] font-black tracking-widest uppercase transition-all rounded-full border ${viewMode === '3D' ? 'bg-purple-500/20 text-purple-400 border-purple-500/50' : 'bg-white/5 text-gray-500 border-white/10 hover:text-white'}`}>3D</button>
            </div>

            {/* Scrollable Content Area - All Sections Combined */}
            <div className="flex-1 overflow-y-auto space-y-8 pr-2">

                {/* 1. Visualization */}
                <div id="gears-viz-container" className="h-[300px] w-full bg-white/[0.02] rounded-3xl overflow-hidden border border-white/10 relative shadow-2xl">
                    <EngineeringVisualization status={status} label="ISO 6336 GEARSET">
                        {viewMode === '2D' ? (
                            <div className="flex flex-col items-center justify-center p-4 h-full">
                                <TechnicalDrawing mode="gear" activeField={null} data={{ z1, z2, gearModule, width: faceWidth }} />
                                <div className="absolute bottom-4 left-4 flex gap-2">
                                    <div className="text-[10px] font-black text-purple-400 uppercase tracking-widest bg-purple-900/30 px-3 py-1.5 rounded-full border border-purple-500/30">
                                        Ratio: {results.ratio.toFixed(2)}:1
                                    </div>
                                    <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
                                        Center Dist: {(results.a).toFixed(1)}mm
                                    </div>
                                </div>
                            </div>
                        ) : (
                            // 3D View Integration
                            <Canvas gl={{ preserveDrawingBuffer: true }} shadows dpr={[1, 2]} camera={{ position: [50, 50, 50], fov: 45 }}>
                                <ambientLight intensity={0.5} />
                                <spotLight position={[50, 50, 50]} angle={0.15} penumbra={1} intensity={1} castShadow />
                                <PresentationControls speed={1.5} global zoom={0.7} polar={[-0.1, Math.PI / 4]}>
                                    <Stage environment="city" intensity={0.5}>
                                        <Gear3D
                                            gearModule={gearModule}
                                            teeth={z1}
                                            faceWidth={faceWidth}
                                            profileShift={x1}
                                            color="#6366f1"
                                            position={[-(results.a) / 2, 0, 0]}
                                        />
                                        <Gear3D
                                            gearModule={gearModule}
                                            teeth={z2}
                                            faceWidth={faceWidth}
                                            profileShift={x2}
                                            color="#a855f7"
                                            position={[(results.a) / 2, 0, 0]}
                                            rotation={[0, 0, Math.PI / z2]} // Mesh alignment offset
                                        />
                                    </Stage>
                                </PresentationControls>
                            </Canvas>
                        )}
                    </EngineeringVisualization>
                </div>

                {/* 2. Design Inputs */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Basic Geometry */}
                    <div className="space-y-4 bg-white/[0.02] border border-white/10 p-6 rounded-3xl">
                        <div className="text-[10px] font-black text-purple-500 uppercase tracking-[0.3em] mb-4">{dict.common?.dimensions || "Geometry"}</div>
                        <div className="grid grid-cols-2 gap-4">
                            <CalculatorInput label={dict.gears?.module || "Module (m)"} unit="mm" value={gearModule} onChange={(e) => setGearModule(Number(e.target.value))} />
                            <CalculatorInput label={dict.gears?.faceWidth || "Face Width"} unit="mm" value={faceWidth} onChange={(e) => setFaceWidth(Number(e.target.value))} />
                            <CalculatorInput label={`${dict.manufacturing?.pinion || "Pinion"} (${dict.gears?.teeth || "z"})`} unit="" value={z1} onChange={(e) => setZ1(Number(e.target.value))} />
                            <CalculatorInput label={`${dict.manufacturing?.gear || "Gear"} (${dict.gears?.teeth || "z"})`} unit="" value={z2} onChange={(e) => setZ2(Number(e.target.value))} />
                            <CalculatorInput label={dict.gears?.helixAngle || "Helix Angle"} unit="°" value={helixAngle} onChange={(e) => setHelixAngle(Number(e.target.value))} />
                        </div>
                    </div>

                    {/* Application & Service Conditions (YR Standard) */}
                    <div className="space-y-4 bg-white/[0.02] border border-white/10 p-6 rounded-3xl">
                        <div className="text-[10px] font-black text-purple-500 uppercase tracking-[0.3em] mb-4">Conditions (Yılmaz Redüktör)</div>
                        <div className="grid grid-cols-2 gap-4">
                            {/* Load Class */}
                            <div className="space-y-2">
                                <label className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block">Load Class</label>
                                <select
                                    className="w-full bg-white/[0.05] border border-white/10 focus:border-purple-500/50 rounded-xl px-3 py-2 text-xs text-white font-mono transition-colors"
                                    value={loadClass}
                                    onChange={(e) => setLoadClass(e.target.value as any)}
                                >
                                    <option value="U" className="bg-[#050709]">Uniform (U)</option>
                                    <option value="M" className="bg-[#050709]">Moderate (M)</option>
                                    <option value="H" className="bg-[#050709]">Heavy Shock (H)</option>
                                </select>
                            </div>
                            {/* Daily Hours */}
                            <div className="space-y-2">
                                <label className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block">Daily Hours</label>
                                <select
                                    className="w-full bg-white/[0.05] border border-white/10 focus:border-purple-500/50 rounded-xl px-3 py-2 text-xs text-white font-mono transition-colors"
                                    value={dailyHours}
                                    onChange={(e) => setDailyHours(Number(e.target.value))}
                                >
                                    <option value={2} className="bg-[#050709]">&lt; 3 Hours</option>
                                    <option value={8} className="bg-[#050709]">3 - 10 Hours</option>
                                    <option value={12} className="bg-[#050709]">&gt; 10 Hours</option>
                                </select>
                            </div>
                            {/* Starts/Hour */}
                            <div className="space-y-2">
                                <label className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block">Starts / Hour</label>
                                <input
                                    type="number"
                                    className="w-full bg-white/[0.05] border border-white/10 focus:border-purple-500/50 rounded-xl px-3 py-2 text-xs text-white font-mono transition-colors focus:outline-none"
                                    value={startsPerHour}
                                    onChange={(e) => setStartsPerHour(Number(e.target.value))}
                                />
                            </div>
                            {/* Output Connection */}
                            <div className="space-y-2">
                                <label className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block">Output Connect.</label>
                                <select
                                    className="w-full bg-white/[0.05] border border-white/10 focus:border-purple-500/50 rounded-xl px-3 py-2 text-xs text-white font-mono transition-colors"
                                    value={connectionType}
                                    onChange={(e) => setConnectionType(e.target.value as any)}
                                >
                                    <option value="coupling" className="bg-[#050709]">Direct Coupling (1.0)</option>
                                    <option value="sprocket" className="bg-[#050709]">Chain Sprocket (1.25)</option>
                                    <option value="v_belt" className="bg-[#050709]">V-Belt (1.5)</option>
                                    <option value="flat_belt" className="bg-[#050709]">Flat Belt (2.5)</option>
                                </select>
                            </div>
                        </div>

                        {/* Calculated Service Factor Display */}
                        <div className="flex items-center justify-between bg-purple-900/20 border border-purple-500/30 px-4 py-3 rounded-2xl">
                            <span className="text-[10px] font-black tracking-widest uppercase text-purple-300">Req. Service Factor ($f_s$)</span>
                            <span className="text-xl font-black text-purple-400 font-mono tracking-tighter">{results.requiredFs.toFixed(2)}</span>
                        </div>
                    </div>

                    {/* Power & Material */}
                    <div className="space-y-4 bg-white/[0.02] border border-white/10 p-6 rounded-3xl lg:col-span-2">
                        <div className="text-[10px] font-black text-purple-500 uppercase tracking-[0.3em] mb-4">{dict.driveTrain?.primeMover || "Motor & Material"}</div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <label className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block">{dict.driveTrain?.primeMover || "Motor Power"}</label>
                                <select
                                    className="w-full bg-white/[0.05] border border-white/10 focus:border-purple-500/50 rounded-xl px-3 py-2 text-xs text-white font-mono transition-colors"
                                    value={selectedPower}
                                    onChange={(e) => setSelectedPower(Number(e.target.value))}
                                >
                                    {IEC_MOTORS.map(m => (
                                        <option key={m.power} value={m.power} className="bg-[#050709]">{m.power} kW</option>
                                    ))}
                                </select>
                            </div>
                            <div className="space-y-2">
                                <label className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block">{dict.common?.material || "Material"}</label>
                                <select
                                    className="w-full bg-white/[0.05] border border-white/10 focus:border-purple-500/50 rounded-xl px-3 py-2 text-xs text-white font-mono transition-colors"
                                    value={materialName}
                                    onChange={(e) => setMaterialName(e.target.value)}
                                >
                                    {GEAR_MATERIALS.map(m => (
                                        <option key={m.name} value={m.name} className="bg-[#050709]">{m.name}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                {/* 3. Safety Factors */}
                <div className="bg-black/60 rounded-[40px] p-8 border border-purple-500/30 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 blur-[100px] rounded-full pointer-events-none" />

                    <div className="flex justify-between items-center mb-6 relative z-10">
                        <span className="text-[10px] font-black tracking-[0.3em] text-gray-400 uppercase">ISO 6336 Safety Factors</span>
                        {status === 'valid' ? <CheckCircle size={18} className="text-purple-400" /> : <AlertTriangle size={18} className="text-red-500 animate-pulse" />}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
                        <div className={`p-6 rounded-3xl border ${results.SF_bending > 1.4 ? 'bg-purple-900/10 border-purple-500/30' : 'bg-red-900/20 border-red-500/50'}`}>
                            <div className="text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-2">Root Bending (SFb)</div>
                            <div className={`text-5xl font-black font-mono tracking-tighter ${results.SF_bending > 1.4 ? 'text-purple-400' : 'text-red-500'}`}>
                                {results.SF_bending.toFixed(2)}
                            </div>
                        </div>
                        <div className={`p-6 rounded-3xl border ${results.SF_contact > 1.0 ? 'bg-purple-900/10 border-purple-500/30' : 'bg-red-900/20 border-red-500/50'}`}>
                            <div className="text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-2">Flank Contact (SFc)</div>
                            <div className={`text-5xl font-black font-mono tracking-tighter ${results.SF_contact > 1.0 ? 'text-purple-400' : 'text-red-500'}`}>
                                {results.SF_contact.toFixed(2)}
                            </div>
                        </div>
                    </div>
                </div>

                {/* 4. Manufacturing Section */}
                <div className="space-y-6">
                    {/* Profile Shift */}
                    <div className="space-y-4 bg-white/[0.02] border border-white/10 p-6 rounded-3xl">
                        <div className="text-[10px] font-black text-purple-500 uppercase tracking-[0.3em] mb-4">{dict.manufacturing?.shiftCoeff || "Profile Shift (x)"}</div>
                        <div className="grid grid-cols-2 gap-4">
                            <CalculatorInput
                                label="Shift x1"
                                unit=""
                                type="text"
                                value={x1}
                                onChange={(e) => {
                                    const val = e.target.value.replace(',', '.');
                                    if (val === '' || val === '-') setX1(val as any);
                                    else if (!isNaN(Number(val))) setX1(Number(val));
                                }}
                            />
                            <CalculatorInput
                                label="Shift x2"
                                unit=""
                                type="text"
                                value={x2}
                                onChange={(e) => {
                                    const val = e.target.value.replace(',', '.');
                                    if (val === '' || val === '-') setX2(val as any);
                                    else if (!isNaN(Number(val))) setX2(Number(val));
                                }}
                            />
                        </div>
                    </div>

                    {/* Manufacturing Dimensions Table */}
                    <div className="space-y-4 bg-white/[0.02] border border-white/10 p-6 rounded-3xl">
                        <div className="text-[10px] font-black text-purple-500 uppercase tracking-[0.3em] mb-4 flex items-center justify-between">
                            <span>{dict.common?.dimensions || "Manufacturing Dims"}</span>
                            <span className="text-[9px] text-gray-500">{dict.common?.metric || "Metric"} (mm)</span>
                        </div>

                        <div className="overflow-x-auto custom-scrollbar">
                            <table className="w-full text-xs text-left">
                                <thead className="bg-[#1a1a1a] text-slate-500 font-bold uppercase text-[9px]">
                                    <tr>
                                        <th className="p-1">Parameter</th>
                                        <th className="p-1 text-center">{dict.manufacturing?.pinion || "Pinion"} (z1)</th>
                                        <th className="p-1 text-center">{dict.manufacturing?.gear || "Gear"} (z2)</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-[#333] font-mono text-slate-300">
                                    <tr>
                                        <td className="p-1 py-1.5 text-slate-500">Ref Diameter (d)</td>
                                        <td className="p-1 text-center">{(gearModule * z1).toFixed(2)}</td>
                                        <td className="p-1 text-center">{(gearModule * z2).toFixed(2)}</td>
                                    </tr>
                                    <tr>
                                        <td className="p-1 py-1.5 text-slate-200 font-bold">Tip Diameter (da)</td>
                                        <td className="p-1 text-center text-ind-orange font-bold">
                                            {results.da1.toFixed(2)}
                                        </td>
                                        <td className="p-1 text-center text-ind-orange font-bold">
                                            {results.da2.toFixed(2)}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td className="p-1 py-1.5 text-slate-500">Root Diameter (df)</td>
                                        <td className="p-1 text-center">{results.df1.toFixed(2)}</td>
                                        <td className="p-1 text-center">{results.df2.toFixed(2)}</td>
                                    </tr>
                                    <tr>
                                        <td className="p-1 py-1.5 text-slate-500">{dict.gears?.addendum || "Addendum (ha)"}</td>
                                        <td className="p-1 text-center text-emerald-400">{(gearModule).toFixed(2)}</td>
                                        <td className="p-1 text-center text-emerald-400">{(gearModule).toFixed(2)}</td>
                                    </tr>
                                    <tr>
                                        <td className="p-1 py-1.5 text-slate-500">{dict.gears?.dedendum || "Dedendum (hf)"}</td>
                                        <td className="p-1 text-center">{(1.25 * gearModule).toFixed(2)}</td>
                                        <td className="p-1 text-center">{(1.25 * gearModule).toFixed(2)}</td>
                                    </tr>
                                    <tr>
                                        <td className="p-1 py-1.5 text-slate-500">{dict.gears?.circularPitch || "Circular Pitch (p)"}</td>
                                        <td className="p-1 text-center" colSpan={2}>{(Math.PI * gearModule).toFixed(2)}</td>
                                    </tr>
                                    <tr>
                                        <td className="p-1 py-1.5 text-slate-500">{dict.manufacturing?.overPins || "Over Pins (M)"}</td>
                                        <td className="p-1 text-center">{results.M1.toFixed(3)}</td>
                                        <td className="p-1 text-center">{results.M2.toFixed(3)}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        {/* Validation Alerts */}
                        <div className="space-y-1 mt-2">
                            {(faceWidth < 6 * gearModule || faceWidth > 10 * gearModule) && (
                                <div className="text-[10px] text-amber-500 flex items-center gap-1 bg-amber-950/30 p-1.5 rounded border border-amber-900/50">
                                    <span>⚠️</span> {dict.gears?.gearModule || "Rec. Width (6m-10m)"}: {(6 * gearModule).toFixed(1)} - {(10 * gearModule).toFixed(1)} mm
                                </div>
                            )}
                            {(z1 < 13 || z2 < 13) && (
                                <div className="text-[10px] text-red-500 flex items-center gap-1 bg-red-950/30 p-1.5 rounded border border-red-900/50">
                                    <span>⚠️</span> ISO: Min 13 teeth to avoid undercut (without shift).
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Stock Check (Shared) */}
                    <StockCheck requirements={[
                        { type: 'round', material: materialName, dims: { d: requiredDia, l: requiredLen }, qty: 2 }
                    ]} />

                    {/* Documentation (Shared) */}
                    <PDFGenerator
                        filename={`GEAR_SET_M${gearModule}`}
                        title="Gear Manufacturing Job Card"
                        inputs={{ z1, z2, module: gearModule, x1, x2, helixAngle, materialName }}
                        results={results}
                        visualElementId="gears-viz-container"
                        notes={[
                            "Dimensions include +0.2mm grinding allowance on flanks.",
                            `Requires Round Stock > Ø${requiredDia.toFixed(0)}mm`,
                            "Deburr all edges 0.5mm"
                        ]}
                    />
                </div>

                {/* 5. Assurance Metadata */}
                <AssumptionPanel metadata={metadata} status={status} />

            </div>
        </div>
    );
}

// ===================================
// SUB-COMPONENTS
// ===================================

// Removed internal StockAvailabilityCheck and ManufacturingActions in favor of shared versions
// See imports above.
