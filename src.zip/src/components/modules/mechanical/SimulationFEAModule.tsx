"use client";

import React, { useState, useMemo, useEffect } from "react";
import {
    Activity, Layers, Plus, Trash2, Maximize2, MoveRight, ChevronDown, CheckCircle, AlertTriangle
} from "lucide-react";
import { MATERIALS_DB } from "@/data/materialsData";
import { solveBeam, BeamType, Load, FEAInput } from "@/lib/feaEngine";
import { DiagramVisualizer } from "@/components/ui/DiagramVisualizer";
import { CalculatorInput } from "@/components/CalculatorInput";
import { AssumptionPanel, CalculationMetadata } from "@/components/ui/AssumptionPanel";
import { PDFReportEngine, ReportMetadata } from "@/lib/pdfReportEngine";
import { ReportSettingsModal } from "@/components/ui/ReportSettingsModal";
import { FileText } from "lucide-react";

export function SimulationFEAModule({ lang, dict }: { lang: string, dict: any }) {
    // Structural State
    const [beamType, setBeamType] = useState<BeamType>('simply-supported');
    const [length, setLength] = useState<number>(5.0); // m
    const [sup1, setSup1] = useState<number>(0.0);
    const [sup2, setSup2] = useState<number>(5.0);

    // Material State
    const [selectedMaterial, setSelectedMaterial] = useState(MATERIALS_DB[0]);
    // Profile State
    const [inertia, setInertia] = useState<number>(1.25); // cm^4 just for easier input then convert to m^4
    const [height, setHeight] = useState<number>(50); // mm

    // Loads State
    const [loads, setLoads] = useState<Load[]>([
        { id: '1', type: 'point', magnitude: 5000, position: 2.5 } // 5kN at midspan
    ]);
    const [isReportModalOpen, setIsReportModalOpen] = useState(false);

    // Validation & Adjustments
    useEffect(() => {
        if (beamType === 'cantilever') {
            setSup1(0);
            setSup2(0);
        } else if (beamType === 'simply-supported') {
            setSup1(0);
            setSup2(length);
        }
    }, [beamType, length]);

    const addLoad = () => {
        setLoads([...loads, {
            id: Date.now().toString(),
            type: 'point',
            magnitude: 1000,
            position: length / 2,
            length: 1
        }]);
    };

    const updateLoad = (id: string, field: keyof Load, value: any) => {
        setLoads(loads.map(l => l.id === id ? { ...l, [field]: value } : l));
    };

    const removeLoad = (id: string) => {
        setLoads(loads.filter(l => l.id !== id));
    };

    // Engine Calculus
    const results = useMemo(() => {
        const I_m4 = inertia * 1e-8; // cm^4 to m^4
        const E_Pa = selectedMaterial.youngsModulus * 1e9; // GPa to Pa

        const input: FEAInput = {
            length,
            supports: [sup1, sup2],
            type: beamType,
            loads,
            E: E_Pa,
            I: I_m4
        };

        try {
            return solveBeam(input, 500);
        } catch (e) {
            console.error("FEA Engine Error:", e);
            return null;
        }
    }, [beamType, length, sup1, sup2, selectedMaterial, inertia, loads]);

    // Post-processing stress
    const stressResults = useMemo(() => {
        if (!results) return null;
        const I_m4 = inertia * 1e-8;
        const c_m = (height / 1000) / 2; // neutral axis to extreme fiber

        // sigma = M * c / I
        const maxStressPa = (results.maxM * c_m) / I_m4;
        const maxStressMPa = maxStressPa
        const sy = selectedMaterial.yield;
        const safetyFactor = Math.abs(maxStressMPa) > 0 ? sy / Math.abs(maxStressMPa) : 999;

        return { maxStressMPa, safetyFactor, sy };
    }, [results, inertia, height, selectedMaterial]);

    const status = stressResults ? (stressResults.safetyFactor > 2 ? 'valid' : stressResults.safetyFactor > 1 ? 'warning' : 'invalid') : 'invalid';

    // Metadata
    const metadata: CalculationMetadata = {
        standardId: "Euler-Bernoulli",
        standardTitle: "Classical Beam Theory (Linear Elastic)",
        version: "1.0",
        assumptions: [
            "Material is isotropic and homogenous",
            "Small deflections assumed (tan θ ≈ θ)",
            "Cross-section remains plane before and after bending",
            "Shear deformation is neglected"
        ]
    };

    const generateEnterpriseReport = async (meta: ReportMetadata) => {
        const engine = new PDFReportEngine(meta);
        let yPos = engine.addMetadataSection();

        yPos = engine.addKPIs([
            { label: "Material", value: selectedMaterial.name },
            { label: "Length", value: `${length} m` },
            { label: "Safety Factor", value: stressResults?.safetyFactor.toFixed(2) || "ERR" }
        ], yPos);

        yPos = engine.addSectionTitle("Beam Geometry & Setup", yPos);
        engine.addTable({
            head: [["Parameter", "Value"]],
            body: [
                ["Topology Type", beamType],
                ["Total Length", `${length} m`],
                ["Support Locations", `[${sup1}m, ${sup2}m]`],
                ["Inertia (I)", `${inertia} cm^4`],
                ["Height (h)", `${height} mm`]
            ],
            startY: yPos
        });

        // Try to add the SVG canvases by capturing the component renders
        const svgEls = document.querySelectorAll('.fea-diagram-svg');
        for (let i = 0; i < svgEls.length; i++) {
            const svgEl = svgEls[i] as SVGSVGElement;
            const title = i === 0 ? "Shear Diagram (V)" : i === 1 ? "Moment Diagram (M)" : "Deflection Diagram (y)";
            yPos = await engine.addImageFromSVG(svgEl, engine.addSectionTitle(title, yPos ? yPos + 60 : 60));
        }

        engine.save(`FEA_Analysis_${meta.referenceNo}.pdf`);
    };

    return (
        <div className="flex flex-col h-full bg-transparent text-slate-200 select-none p-6 relative overflow-hidden">
            {/* Ambient Background */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-red-500/5 blur-[120px] rounded-full pointer-events-none" />

            {/* Toolbar */}
            <div className="flex items-center gap-2 mb-6 justify-end relative z-10">
                <div className="mr-auto">
                    <span className="text-[10px] font-black uppercase text-red-500/80 tracking-[0.3em] bg-red-500/10 px-3 py-1.5 rounded-full border border-red-500/20 shadow-[0_0_15px_rgba(239,68,68,0.1)]">Advanced FEA Solver 1D</span>
                </div>
                <button
                    onClick={() => setIsReportModalOpen(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-300 hover:text-white transition-all shadow-xl active:scale-95"
                >
                    <FileText size={14} className="text-red-500" /> Executive Report
                </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-6 pr-2 relative z-10 custom-scrollbar">

                {/* Grid Layout: Config vs Visuals */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

                    {/* LEFT COLUMN: SETUP & CONFIG */}
                    <div className="lg:col-span-5 space-y-6">

                        {/* Material & Profile Section */}
                        <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-6 backdrop-blur-md">
                            <div className="flex items-center gap-2 mb-6">
                                <Layers size={16} className="text-red-500" />
                                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Material & Section</h3>
                            </div>

                            <div className="space-y-4">
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest block">Material Selection</label>
                                    <div className="relative">
                                        <select
                                            className="w-full bg-black/40 border border-white/10 focus:border-red-500/50 rounded-xl pl-3 pr-10 py-3 text-xs text-white font-mono transition-colors appearance-none"
                                            value={selectedMaterial.name}
                                            onChange={(e) => setSelectedMaterial(MATERIALS_DB.find(m => m.name === e.target.value) || MATERIALS_DB[0])}
                                        >
                                            {MATERIALS_DB.map(m => (
                                                <option key={m.name} value={m.name} className="bg-[#050709]">{m.name}</option>
                                            ))}
                                        </select>
                                        <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                                    </div>
                                    <div className="flex justify-between text-[9px] text-slate-500 font-mono px-1">
                                        <span>E: {selectedMaterial.youngsModulus} GPa</span>
                                        <span>Sy: {selectedMaterial.yield} MPa</span>
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <CalculatorInput label="Inertia (I)" unit="cm⁴" value={inertia} onChange={(e) => setInertia(Number(e.target.value))} />
                                    <CalculatorInput label="Height (h)" unit="mm" value={height} onChange={(e) => setHeight(Number(e.target.value))} />
                                </div>
                            </div>
                        </div>

                        {/* Beam Setup Section */}
                        <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-6 backdrop-blur-md">
                            <div className="flex items-center gap-2 mb-6">
                                <Maximize2 size={16} className="text-red-500" />
                                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Beam Topology</h3>
                            </div>

                            <div className="space-y-4">
                                <div className="flex bg-black/40 p-1 rounded-xl border border-white/5">
                                    {(['simply-supported', 'cantilever', 'overhanging'] as const).map(bt => (
                                        <button
                                            key={bt}
                                            onClick={() => setBeamType(bt)}
                                            className={`flex-1 text-[9px] font-black tracking-widest uppercase transition-all py-2 rounded-lg ${beamType === bt ? 'bg-red-500/20 text-red-400 shadow-lg' : 'text-slate-500 hover:text-white'}`}
                                        >
                                            {bt.split('-')[0]}
                                        </button>
                                    ))}
                                </div>

                                <CalculatorInput label="Total Length" unit="m" value={length} onChange={(e) => setLength(Number(e.target.value))} />

                                {beamType === 'overhanging' && (
                                    <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/5">
                                        <CalculatorInput label="Support 1 (x)" unit="m" value={sup1} onChange={(e) => setSup1(Number(e.target.value))} />
                                        <CalculatorInput label="Support 2 (x)" unit="m" value={sup2} onChange={(e) => setSup2(Number(e.target.value))} />
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Loading Conditions */}
                        <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-6 backdrop-blur-md flex flex-col h-[300px]">
                            <div className="flex justify-between items-center mb-4">
                                <div className="flex items-center gap-2">
                                    <MoveRight size={16} className="text-red-500" />
                                    <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Load Cases</h3>
                                </div>
                                <button
                                    onClick={addLoad}
                                    className="p-1.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-all border border-red-500/20"
                                >
                                    <Plus size={14} />
                                </button>
                            </div>

                            <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
                                {loads.length === 0 && (
                                    <div className="text-[10px] text-slate-500 text-center py-4 font-mono">No active loads.</div>
                                )}
                                {loads.map((load, index) => (
                                    <div key={load.id} className="bg-black/40 border border-white/5 rounded-xl p-3 relative group">
                                        <button
                                            onClick={() => removeLoad(load.id)}
                                            className="absolute top-2 right-2 p-1 text-slate-600 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100"
                                        >
                                            <Trash2 size={12} />
                                        </button>

                                        <div className="flex gap-2 mb-3 pr-6">
                                            <select
                                                className="bg-transparent text-[10px] font-bold text-white uppercase tracking-widest focus:outline-none"
                                                value={load.type}
                                                onChange={(e) => updateLoad(load.id, 'type', e.target.value)}
                                            >
                                                <option value="point" className="bg-[#050709]">Point Load</option>
                                                <option value="distributed" className="bg-[#050709]">Distributed (UDL)</option>
                                                <option value="moment" className="bg-[#050709]">Applied Moment</option>
                                            </select>
                                        </div>

                                        <div className="grid grid-cols-2 gap-2">
                                            <div>
                                                <label className="text-[8px] text-slate-500 block mb-1">Magnitude ({load.type === 'moment' ? 'Nm' : load.type === 'distributed' ? 'N/m' : 'N'})</label>
                                                <input
                                                    type="number"
                                                    className="w-full bg-white/5 border border-white/5 rounded px-2 py-1 text-xs text-white font-mono focus:border-red-500/50 outline-none"
                                                    value={load.magnitude}
                                                    onChange={(e) => updateLoad(load.id, 'magnitude', Number(e.target.value))}
                                                />
                                            </div>
                                            <div>
                                                <label className="text-[8px] text-slate-500 block mb-1">Position (m)</label>
                                                <input
                                                    type="number"
                                                    step="0.1"
                                                    className="w-full bg-white/5 border border-white/5 rounded px-2 py-1 text-xs text-white font-mono focus:border-red-500/50 outline-none"
                                                    value={load.position}
                                                    onChange={(e) => updateLoad(load.id, 'position', Number(e.target.value))}
                                                />
                                            </div>
                                            {load.type === 'distributed' && (
                                                <div className="col-span-2 mt-1">
                                                    <label className="text-[8px] text-slate-500 block mb-1">Load Length (m)</label>
                                                    <input
                                                        type="number"
                                                        step="0.1"
                                                        className="w-full bg-white/5 border border-white/5 rounded px-2 py-1 text-xs text-white font-mono focus:border-red-500/50 outline-none"
                                                        value={load.length || 0}
                                                        onChange={(e) => updateLoad(load.id, 'length', Number(e.target.value))}
                                                    />
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                    </div>

                    {/* RIGHT COLUMN: VISUALS & RESULTS */}
                    <div className="lg:col-span-7 flex flex-col gap-6">

                        {/* KPI Dashboard */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div className="bg-[#0a0e14] border border-white/5 p-4 rounded-2xl relative overflow-hidden">
                                <div className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1 z-10 relative">Max Deflection</div>
                                <div className="text-xl font-black font-mono text-white z-10 relative">{(results?.maxY || 0) * 1000 >= 1 || (results?.maxY || 0) * 1000 <= -1 ? ((results?.maxY || 0) * 1000).toFixed(2) : ((results?.maxY || 0) * 1000).toExponential(2)} <span className="text-[10px] text-slate-500">mm</span></div>
                            </div>
                            <div className="bg-[#0a0e14] border border-white/5 p-4 rounded-2xl relative overflow-hidden">
                                <div className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1 z-10 relative">Max Stress</div>
                                <div className="text-xl font-black font-mono text-white z-10 relative">{stressResults?.maxStressMPa.toFixed(1) || 0} <span className="text-[10px] text-slate-500">MPa</span></div>
                            </div>
                            <div className={`col-span-2 p-4 rounded-2xl relative overflow-hidden border ${status === 'valid' ? 'bg-emerald-500/10 border-emerald-500/30' : status === 'warning' ? 'bg-amber-500/10 border-amber-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                                <div className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Safety Factor (SF)</div>
                                <div className="flex items-end gap-3 justify-between">
                                    <div className="text-3xl font-black font-mono text-white tracking-tighter">
                                        {stressResults?.safetyFactor === 999 ? '∞' : stressResults?.safetyFactor.toFixed(2)}
                                    </div>
                                    {status === 'valid' ? <CheckCircle size={20} className="text-emerald-400 mb-1" /> : <AlertTriangle size={20} className={`${status === 'invalid' ? 'text-red-500' : 'text-amber-500'} mb-1`} />}
                                </div>
                            </div>
                        </div>

                        {/* Diagrams */}
                        <div className="bg-[#050709] border border-white/10 rounded-[32px] p-6 flex-1 flex flex-col gap-6 shadow-2xl relative">

                            <div className="flex justify-between items-center px-2">
                                <div className="text-[11px] font-black text-white tracking-[0.2em] uppercase flex items-center gap-2">
                                    <Activity size={14} className="text-red-500" />
                                    Internal Forces & Kinematics
                                </div>
                                <div className="flex items-center gap-4 text-[9px] font-mono text-slate-500">
                                    <span>R1: {(results?.R1 || 0).toFixed(1)} N</span>
                                    {beamType !== 'cantilever' && <span>R2: {(results?.R2 || 0).toFixed(1)} N</span>}
                                    {beamType === 'cantilever' && <span>MR: {(results?.MR || 0).toFixed(1)} Nm</span>}
                                </div>
                            </div>

                            <div className="flex-1 flex flex-col gap-4">
                                {results && (
                                    <>
                                        <DiagramVisualizer
                                            title="Shear Force (V)" unit="N"
                                            x={results.x} data={results.V}
                                            color="#3b82f6" fillColor="rgba(59,130,246,0.1)"
                                            height={100}
                                        />
                                        <DiagramVisualizer
                                            title="Bending Moment (M)" unit="Nm"
                                            x={results.x} data={results.M}
                                            color="#ef4444" fillColor="rgba(239,68,68,0.1)"
                                            height={100}
                                        />
                                        <DiagramVisualizer
                                            title="Deflection (y)" unit="m"
                                            x={results.x} data={results.y}
                                            color="#10b981" fillColor="rgba(16,185,129,0.1)"
                                            height={100}
                                        />
                                    </>
                                )}
                            </div>
                        </div>

                    </div>
                </div>

                <AssumptionPanel metadata={metadata} status={status} />
            </div>

            <ReportSettingsModal
                isOpen={isReportModalOpen}
                onClose={() => setIsReportModalOpen(false)}
                onGenerate={generateEnterpriseReport}
                defaultTitle="Linear Structural Evaluation"
            />
        </div>
    );
}
