import { useState, useMemo, useEffect } from 'react';
import { useCADCanvasStore } from '@/store/CADCanvasStore';
import { Plus, BookOpen, AlertTriangle, ShoppingCart, FileText } from 'lucide-react';
import { MATERIALS_DB, getMaterialCategories, getMaterialsByCategory } from '@/data/materialsData';
import { CUTTING_METHODS, CuttingMethod, BASELINE_PRICES } from '@/data/productionParams';
import { useProjectStore } from '@/store/projectStore';
import { PDFReportEngine, ReportMetadata } from '@/lib/pdfReportEngine';
import { ReportSettingsModal } from '@/components/ui/ReportSettingsModal';

type Shape = 'plate' | 'round' | 'tube' | 'hollow-rect' | 'angle' | 'channel' | 'i-beam' | 'hex';

const SHAPES: { id: Shape; label: string }[] = [
    { id: 'plate', label: 'Plate' },
    { id: 'round', label: 'Round Bar' },
    { id: 'tube', label: 'Tube' },
    { id: 'hollow-rect', label: 'Box' },
    { id: 'angle', label: 'Angle' },
    { id: 'channel', label: 'Channel' },
    { id: 'i-beam', label: 'I-Beam' },
    { id: 'hex', label: 'Hexagon' },
];

export default function ProfileWeightModule() {
    const { addShape } = useCADCanvasStore();
    const { addItem } = useProjectStore();

    // Core parameters
    const [shape, setShape] = useState<Shape>('plate');
    const [category, setCategory] = useState('Aluminum');
    const [material, setMaterial] = useState('6061-T6 (US Standard)');
    const [quantity, setQuantity] = useState(1);
    const [viewMode, setViewMode] = useState<'2d' | '3d'>('2d');
    const [isReportModalOpen, setIsReportModalOpen] = useState(false);

    // Dimensions
    const [length, setLength] = useState(1000);
    const [width, setWidth] = useState(100);
    const [thickness, setThickness] = useState(10);
    const [diameter, setDiameter] = useState(50);
    const [wallThickness, setWallThickness] = useState(5);
    const [height, setHeight] = useState(100);
    const [flangeW, setFlangeW] = useState(50);
    const [webH, setWebH] = useState(100);
    const [flangeT, setFlangeT] = useState(8);
    const [webT, setWebT] = useState(6);

    // Production Parameters
    const [cuttingMethod, setCuttingMethod] = useState<CuttingMethod>('Laser');
    const [nestingEfficiency, setNestingEfficiency] = useState(85); // %
    const [pricePerKg, setPricePerKg] = useState<number>(4.50);

    const categories = getMaterialCategories();
    const availableMaterials = getMaterialsByCategory(category);

    // Auto-update default prices/materials
    useEffect(() => {
        if (availableMaterials.length > 0 && !availableMaterials.find(m => m.name === material)) {
            setMaterial(availableMaterials[0].name);
        }

        const matData = availableMaterials.find(m => m.name === material) || availableMaterials[0];
        if (matData?.basePrice) {
            setPricePerKg(matData.basePrice);
        } else {
            const defaultPrice = (BASELINE_PRICES as Record<string, number>)[category] || 5.00;
            setPricePerKg(defaultPrice);
        }
    }, [category, material]);

    const materialData = useMemo(() => MATERIALS_DB.find(m => m.name === material), [material]);
    const density = materialData?.density || 2.7;

    // Advanced Calculation Engine
    const result = useMemo(() => {
        let netVolume = 0; // mm³
        switch (shape) {
            case 'plate': netVolume = length * width * thickness; break;
            case 'round': netVolume = Math.PI * Math.pow(diameter / 2, 2) * length; break;
            case 'tube':
                const outerR = diameter / 2;
                const innerR = outerR - wallThickness;
                netVolume = Math.PI * (outerR * outerR - innerR * innerR) * length;
                break;
            case 'hollow-rect':
                netVolume = (width * height - (width - 2 * wallThickness) * (height - 2 * wallThickness)) * length;
                break;
            case 'angle': netVolume = (width * thickness + (height - thickness) * thickness) * length; break;
            case 'channel': netVolume = (width * thickness * 2 + (height - 2 * thickness) * thickness) * length; break;
            case 'i-beam': netVolume = (2 * flangeW * flangeT + (webH - 2 * flangeT) * webT) * length; break;
            case 'hex': netVolume = (3 * Math.sqrt(3) / 2) * Math.pow(diameter / 2, 2) * length; break;
        }

        const kerfSpec = CUTTING_METHODS.find(c => c.method === cuttingMethod);
        const kerfWidth = kerfSpec ? kerfSpec.widthMm : 0;
        let grossVolume = 0;
        if (shape === 'plate') {
            grossVolume = (length + kerfWidth) * (width + kerfWidth) * thickness;
        } else {
            grossVolume = (netVolume / length) * (length + kerfWidth);
        }

        const netWeightKg = (netVolume / 1000 * density) / 1000;
        const grossWeightKg = (grossVolume / 1000 * density) / 1000;
        const eff = Math.min(Math.max(nestingEfficiency, 10), 100) / 100;
        const materialConsumedKg = grossWeightKg / eff;

        const totalWeight = materialConsumedKg * quantity;
        const totalCost = totalWeight * pricePerKg;

        return {
            netWeightKg: netWeightKg,
            totalWeightKg: materialConsumedKg,
            totalCost: totalCost,
            display: {
                netWeight: (netWeightKg * quantity).toFixed(3),
                totalWeight: totalWeight.toFixed(3),
                totalCost: totalCost.toFixed(2),
                scrapWeight: ((materialConsumedKg - netWeightKg) * quantity).toFixed(3),
                scrapCost: ((materialConsumedKg - netWeightKg) * quantity * pricePerKg).toFixed(2),
                partCost: (netWeightKg * quantity * pricePerKg).toFixed(2)
            }
        };
    }, [shape, length, width, thickness, diameter, wallThickness, height, flangeW, webH, flangeT, webT, density, quantity, cuttingMethod, nestingEfficiency, pricePerKg]);

    const addToProject = () => {
        addItem({
            name: `${SHAPES.find(s => s.id === shape)?.label} ${width || diameter}x${height || thickness} L${length}`,
            category: category,
            material: material,
            quantity: quantity,
            weightPerUnit: result.totalWeightKg,
            costPerUnit: result.totalWeightKg * pricePerKg
        });
    };

    const exportToCAD = () => {
        const shapes: any[] = [];
        const createPolyline = (points: { x: number, y: number }[]) => ({
            type: 'polyline', points, style: { strokeColor: '#00e5ff', strokeWidth: 2, fillOpacity: 0.1, fillColor: '#00e5ff' }, locked: false, visible: true, layer: 'profile'
        });
        const createCircle = (radius: number) => ({
            type: 'circle', points: [{ x: 0, y: 0 }, { x: radius, y: 0 }], style: { strokeColor: '#00e5ff', strokeWidth: 2, fillOpacity: 0.1, fillColor: '#00e5ff' }, locked: false, visible: true, layer: 'profile'
        });

        switch (shape) {
            case 'plate': shapes.push({ type: 'rectangle', points: [{ x: -width / 2, y: -thickness / 2 }, { x: width / 2, y: thickness / 2 }], style: { strokeColor: '#00e5ff', strokeWidth: 2, fillOpacity: 0.1, fillColor: '#00e5ff' }, visible: true, layer: 'profile' }); break;
            case 'round': shapes.push(createCircle(diameter / 2)); break;
            case 'tube': shapes.push(createCircle(diameter / 2)); shapes.push(createCircle((diameter / 2) - wallThickness)); break;
            case 'hollow-rect':
                shapes.push({ type: 'rectangle', points: [{ x: -width / 2, y: -height / 2 }, { x: width / 2, y: height / 2 }], style: { strokeColor: '#00e5ff', strokeWidth: 2 }, visible: true, layer: 'profile' });
                shapes.push({ type: 'rectangle', points: [{ x: -(width / 2 - wallThickness), y: -(height / 2 - wallThickness) }, { x: (width / 2 - wallThickness), y: (height / 2 - wallThickness) }], style: { strokeColor: '#00e5ff', strokeWidth: 2 }, visible: true, layer: 'profile' });
                break;
            case 'angle': shapes.push(createPolyline([{ x: 0, y: 0 }, { x: width, y: 0 }, { x: width, y: thickness }, { x: thickness, y: thickness }, { x: thickness, y: height }, { x: 0, y: height }, { x: 0, y: 0 }])); break;
            case 'channel': shapes.push(createPolyline([{ x: 0, y: 0 }, { x: width, y: 0 }, { x: width, y: thickness }, { x: thickness, y: thickness }, { x: thickness, y: height - thickness }, { x: width, y: height - thickness }, { x: width, y: height }, { x: 0, y: height }, { x: 0, y: 0 }])); break;
            case 'i-beam':
                shapes.push({ type: 'rectangle', points: [{ x: -flangeW / 2, y: webH / 2 }, { x: flangeW / 2, y: webH / 2 + flangeT }], style: { strokeColor: '#00e5ff', strokeWidth: 2 }, visible: true, layer: 'profile' });
                shapes.push({ type: 'rectangle', points: [{ x: -flangeW / 2, y: -webH / 2 - flangeT }, { x: flangeW / 2, y: -webH / 2 }], style: { strokeColor: '#00e5ff', strokeWidth: 2 }, visible: true, layer: 'profile' });
                shapes.push({ type: 'rectangle', points: [{ x: -webT / 2, y: -webH / 2 }, { x: webT / 2, y: webH / 2 }], style: { strokeColor: '#00e5ff', strokeWidth: 2 }, visible: true, layer: 'profile' });
                break;
            case 'hex':
                const points = [];
                for (let i = 0; i < 6; i++) {
                    const angle = (i * 60 - 30) * Math.PI / 180;
                    points.push({ x: (diameter / 2) * Math.cos(angle), y: (diameter / 2) * Math.sin(angle) });
                }
                points.push(points[0]);
                shapes.push(createPolyline(points));
                break;
        }
        shapes.forEach(s => addShape(s));
    };

    const generateEnterpriseReport = async (metadata: ReportMetadata) => {
        const engine = new PDFReportEngine(metadata);

        let yPos = engine.addMetadataSection();

        yPos = engine.addKPIs([
            { label: "Material", value: material },
            { label: "Quantity", value: quantity.toString() },
            { label: "Total Cost", value: `$${result.totalCost.toFixed(2)}` }
        ], yPos);

        yPos = engine.addSectionTitle("Profile Parameters", yPos);

        const paramsData = [
            ["Shape", SHAPES.find(s => s.id === shape)?.label || shape],
            ["Length", `${length} mm`],
            ["Net Weight (ea)", `${result.netWeightKg.toFixed(3)} kg`],
            ["Gross Weight (ea)", `${result.totalWeightKg.toFixed(3)} kg`],
            ["Scrap Loss (Total)", `${result.display.scrapWeight} kg`],
            ["Total Required Mtl", `${result.display.totalWeight} kg`]
        ];

        engine.addTable({
            head: [["Parameter", "Value"]],
            body: paramsData,
            startY: yPos
        });

        // Try to capture SVG preview
        const svgEl = document.querySelector('.profile-preview-svg') as SVGSVGElement;
        if (svgEl) {
            await engine.addImageFromSVG(svgEl, engine.addSectionTitle("Cross-Section Diagram", yPos + 60));
        }

        engine.save(`Profile_DataSheet_${metadata.referenceNo}.pdf`);
    };

    return (
        <div className="flex flex-col gap-4 h-full p-1 overflow-y-auto">
            <div className="grid grid-cols-4 gap-1.5">
                {SHAPES.map(s => (
                    <button key={s.id} onClick={() => setShape(s.id)} className={`py-2 px-1 rounded-md text-[9px] font-black uppercase transition-all border ${shape === s.id ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/50' : 'bg-white/[0.02] text-gray-500 border-white/5 hover:bg-white/[0.05]'}`}>
                        {s.label}
                    </button>
                ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-xl p-4 bg-white/[0.02] border border-white/5 relative overflow-hidden">
                    <div className="flex justify-between items-center mb-4">
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">Viewer</span>
                        <div className="flex gap-2">
                            <button onClick={() => setViewMode('2d')} className={`px-2 py-0.5 rounded text-[8px] font-bold ${viewMode === '2d' ? 'bg-cyan-500 text-black' : 'text-gray-500'}`}>2D</button>
                            <button onClick={() => setViewMode('3d')} className={`px-2 py-0.5 rounded text-[8px] font-bold ${viewMode === '3d' ? 'bg-cyan-500 text-black' : 'text-gray-500'}`}>3D</button>
                        </div>
                    </div>
                    <div className="h-24 flex items-center justify-center">
                        <ShapePreview shape={shape} viewMode={viewMode} w={width} h={height} t={thickness} d={diameter} wt={wallThickness} fW={flangeW} wH={webH} fT={flangeT} wT={webT} />
                    </div>
                </div>

                <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                        <div>
                            <label className="block text-[8px] font-bold text-gray-500 uppercase mb-1">Category</label>
                            <select value={category} onChange={e => setCategory(e.target.value)} className="w-full px-2 py-1.5 bg-black/40 border border-white/10 rounded text-[11px] text-white outline-none">
                                {categories.map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-[8px] font-bold text-gray-500 uppercase mb-1">Density</label>
                            <div className="px-2 py-1.5 bg-black/40 border border-white/10 rounded text-[11px] text-cyan-400 font-mono">{density.toFixed(3)}</div>
                        </div>
                    </div>
                    <div>
                        <label className="block text-[8px] font-bold text-gray-500 uppercase mb-1">Material Alloy</label>
                        <select value={material} onChange={e => setMaterial(e.target.value)} className="w-full px-2 py-1.5 bg-black/40 border border-white/10 rounded text-[11px] text-white outline-none">
                            {availableMaterials.map(m => <option key={m.name} value={m.name}>{m.name}</option>)}
                        </select>
                    </div>
                </div>
            </div>

            <div className="p-4 bg-white/[0.01] border border-white/5 rounded-xl">
                <div className="grid grid-cols-3 gap-3">
                    <InputField label="Length (mm)" value={length} onChange={setLength} />
                    {shape === 'plate' && <><InputField label="Width" value={width} onChange={setWidth} /><InputField label="Thickness" value={thickness} onChange={setThickness} /></>}
                    {shape === 'round' && <InputField label="Diameter" value={diameter} onChange={setDiameter} />}
                    {shape === 'hex' && <InputField label="Diameter" value={diameter} onChange={setDiameter} />}
                    {shape === 'tube' && <><InputField label="Outer Ø" value={diameter} onChange={setDiameter} /><InputField label="Wall" value={wallThickness} onChange={setWallThickness} /></>}
                    {shape === 'hollow-rect' && <><InputField label="Width" value={width} onChange={setWidth} /><InputField label="Height" value={height} onChange={setHeight} /><InputField label="Wall" value={wallThickness} onChange={setWallThickness} /></>}
                    <InputField label="Quantity" value={quantity} onChange={setQuantity} />
                </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
                <div className="p-3 rounded-lg border border-white/5 bg-white/[0.02]">
                    <span className="text-[8px] text-gray-500 uppercase font-bold">Net Weight</span>
                    <div className="text-xl font-black font-mono text-white">{result.display.netWeight}<span className="text-[10px] text-gray-500 ml-1">kg</span></div>
                </div>
                <div className="p-3 rounded-lg border border-red-500/10 bg-red-500/5">
                    <span className="text-[8px] text-red-400 uppercase font-bold">Scrap Loss</span>
                    <div className="text-xl font-black font-mono text-white">{result.display.scrapWeight}<span className="text-[10px] text-red-500/50 ml-1">kg</span></div>
                </div>
                <div className="p-3 rounded-lg border border-emerald-500/10 bg-emerald-500/5">
                    <span className="text-[8px] text-emerald-400 uppercase font-bold">Total Cost</span>
                    <div className="text-xl font-black font-mono text-white">${result.display.totalCost}</div>
                </div>
            </div>

            <div className="flex gap-2">
                <button onClick={addToProject} className="flex-1 py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-black uppercase text-[10px] rounded-lg flex items-center justify-center gap-2 transition-all">
                    <ShoppingCart size={14} /> Add to BOM
                </button>
                <button onClick={() => setIsReportModalOpen(true)} className="px-4 py-3 bg-white/[0.05] hover:bg-white/[0.1] text-white font-black uppercase text-[10px] rounded-lg flex items-center justify-center gap-2 transition-all">
                    <FileText size={14} /> PDF
                </button>
                <button onClick={exportToCAD} className="px-4 py-3 bg-white/[0.05] hover:bg-white/[0.1] text-white font-black uppercase text-[10px] rounded-lg flex items-center justify-center gap-2 transition-all">
                    <Plus size={14} /> CAD
                </button>
            </div>

            <ReportSettingsModal
                isOpen={isReportModalOpen}
                onClose={() => setIsReportModalOpen(false)}
                onGenerate={generateEnterpriseReport}
                defaultTitle="Material Profile Datasheet"
            />
        </div>
    );
}

function ShapePreview({ shape, viewMode, w, h, t, d, wt }: any) {
    return (
        <svg viewBox="0 0 140 80" className="w-full h-full drop-shadow-2xl profile-preview-svg">
            <g transform={`translate(70, 40)`}>
                {shape === 'plate' && <rect x={-30} y={-5} width={60} height={10} fill="#06b6d4" fillOpacity="0.4" stroke="#06b6d4" strokeWidth="1.5" />}
                {shape === 'round' && <circle r={20} fill="#06b6d4" fillOpacity="0.4" stroke="#06b6d4" strokeWidth="1.5" />}
                {shape === 'tube' && <><circle r={22} fill="none" stroke="#06b6d4" strokeWidth="4" /><circle r={18} fill="none" stroke="#06b6d4" strokeWidth="1" strokeOpacity="0.3" /></>}
                {shape === 'hollow-rect' && <><rect x={-25} y={-15} width={50} height={30} fill="none" stroke="#06b6d4" strokeWidth="4" /><rect x={-20} y={-10} width={40} height={20} fill="none" stroke="#06b6d4" strokeWidth="1" strokeOpacity="0.3" /></>}
                {shape === 'angle' && <path d={`M -20,-15 L -20,15 L 20,15 L 20,10 L -15,10 L -15,-15 Z`} fill="#06b6d4" fillOpacity="0.4" stroke="#06b6d4" strokeWidth="1.5" />}
                {shape === 'channel' && <path d={`M-25,-15 L25,-15 L25,-10 L-20,-10 L-20,10 L25,10 L25,15 L-25,15 Z`} fill="#06b6d4" fillOpacity="0.4" stroke="#06b6d4" strokeWidth="1.5" />}
                {shape === 'i-beam' && <><rect x={-20} y={-20} width={40} height={5} fill="#06b6d4" fillOpacity="0.4" /><rect x={-3} y={-15} width={6} height={30} fill="#06b6d4" fillOpacity="0.4" /><rect x={-20} y={15} width={40} height={5} fill="#06b6d4" fillOpacity="0.4" /></>}
                {shape === 'hex' && <polygon points="0,-22 19,-11 19,11 0,22 -19,11 -19,-11" fill="#06b6d4" fillOpacity="0.4" stroke="#06b6d4" strokeWidth="1.5" />}
            </g>
        </svg>
    );
}

function InputField({ label, value, onChange }: any) {
    return (
        <div>
            <label className="block text-[8px] font-bold text-gray-500 uppercase mb-1">{label}</label>
            <input type="number" step="any" value={value} onChange={e => onChange(Number(e.target.value))}
                className="w-full px-2 py-1.5 bg-black/40 border border-white/10 rounded text-[11px] font-mono font-bold text-white outline-none focus:border-cyan-500"
            />
        </div>
    );
}
