import { useState, useMemo, useEffect } from 'react';
import { useOSStore } from '@/store/osStore';
import { AlertCircle, Thermometer, Maximize2, MoveVertical } from 'lucide-react';
import { MATERIALS_DB, getMaterialCategories, getMaterialsByCategory } from '@/data/materialsData';

export default function ThermalExpansionModule() {
    const [category, setCategory] = useState('Aluminum');
    const [material, setMaterial] = useState('6061-T6 (US Standard)');

    // Thermal parameters
    const [initialLength, setInitialLength] = useState(1000); // mm
    const [t0, setT0] = useState(20); // Initial Temp °C
    const [t1, setT1] = useState(150); // Target Temp °C

    const categories = getMaterialCategories();
    const availableMaterials = getMaterialsByCategory(category);

    // Auto-update default materials
    useEffect(() => {
        if (availableMaterials.length > 0 && !availableMaterials.find(m => m.name === material)) {
            setMaterial(availableMaterials[0].name);
        }
    }, [category, availableMaterials, material]);

    const materialData = useMemo(() => MATERIALS_DB.find(m => m.name === material), [material]);
    const alpha = materialData?.thermalExp || 0; // μm/(m·K)
    const meltingPoint = materialData?.meltingPoint || 1000;

    // Physics Calculations (ΔL = α * L0 * ΔT)
    const result = useMemo(() => {
        const deltaT = t1 - t0;
        // deltaL in mm
        // alpha is 10^-6 / K
        // L0 is in mm
        const deltaL = initialLength * alpha * deltaT * 1e-6;
        const finalLength = initialLength + deltaL;
        const isExpanding = deltaT > 0;

        // Critical Analysis
        let dangerLevel = 'Safe'; // Safe, Caution, Critical
        let dangerMsg = '';

        if (t1 > meltingPoint) {
            dangerLevel = 'Critical';
            dangerMsg = `Material exceeds melting point (${meltingPoint}°C). Complete failure.`;
        } else if (category === 'Aluminum' && t1 > 200) {
            dangerLevel = 'Caution';
            dangerMsg = `Temper loss risk (>200°C). T6 strength will degrade significantly over time.`;
        } else if (category === 'Plastic' && t1 > (meltingPoint * 0.7)) {
            dangerLevel = 'Caution';
            dangerMsg = `Approaching glass transition or heat deflection limit. Loss of rigidity expected.`;
        } else if (Math.abs(deltaT) > 500) {
            dangerLevel = 'Caution';
            dangerMsg = `Extreme thermal shock range. Micro-cracking possible depending on geometry.`;
        }

        return {
            deltaT,
            deltaL: deltaL.toFixed(4), // highly precise
            finalLength: finalLength.toFixed(4),
            isExpanding,
            dangerLevel,
            dangerMsg,
            strain: (deltaL / initialLength * 100).toFixed(4) // percentage
        };
    }, [initialLength, t0, t1, alpha, meltingPoint, category]);

    // Visually exaggerated proportion for UI representation (clamp it to look good)
    const getVisualPercent = () => {
        const pct = (parseFloat(result.deltaL) / initialLength) * 100 * 50; // Exaggerate 50x for visual flair
        if (pct === 0) return 0;
        const maxExaggeration = 25; // max 25% of the bar can be the delta
        return Math.min(Math.max(pct, -maxExaggeration), maxExaggeration);
    };

    const visualDelta = getVisualPercent();
    const barBasePct = result.isExpanding ? 100 - visualDelta : 100 + Math.abs(visualDelta);

    return (
        <div className="flex flex-col gap-4 h-full p-2 overflow-y-auto">
            {/* Intelligent Material Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-white/[0.02] border border-white/5 rounded-xl backdrop-blur-xl space-y-3">
                    <h3 className="text-[10px] font-bold text-gray-400 tracking-[0.2em] uppercase mb-4 border-b border-white/10 pb-2 flex items-center gap-2">
                        <MoveVertical size={12} className="text-pink-500" /> Material Specs
                    </h3>
                    <div>
                        <label className="block text-[8px] font-bold text-gray-500 uppercase tracking-widest mb-1">Alloy Category</label>
                        <select value={category} onChange={e => setCategory(e.target.value)} className="w-full px-3 py-2 bg-black/40 border border-white/10 rounded-lg text-xs font-bold text-white focus:border-pink-500 outline-none transition-colors">
                            {categories.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-[8px] font-bold text-gray-500 uppercase tracking-widest mb-1 flex justify-between">
                            <span>Exact Alloy</span>
                            <span className="text-pink-400">α = {alpha} μm/(m·K)</span>
                        </label>
                        <select value={material} onChange={e => setMaterial(e.target.value)} className="w-full px-3 py-2 bg-black/40 border border-white/10 rounded-lg text-xs font-bold text-white focus:border-pink-500 outline-none transition-colors">
                            {availableMaterials.map(m => <option key={m.name} value={m.name}>{m.name}</option>)}
                        </select>
                    </div>
                </div>

                {/* Thermal Inputs */}
                <div className="p-4 bg-white/[0.02] border border-white/5 rounded-xl backdrop-blur-xl flex flex-col justify-between">
                    <h3 className="text-[10px] font-bold text-gray-400 tracking-[0.2em] uppercase mb-4 border-b border-white/10 pb-2 flex items-center gap-2">
                        <Thermometer size={12} className="text-orange-500" /> Temperature Vectors
                    </h3>
                    <div className="space-y-4">
                        <ThermalSlider label="Initial Temp (T0)" value={t0} onChange={setT0} min={-100} max={1000} color="cyan" />
                        <ThermalSlider label="Target Temp (T1)" value={t1} onChange={setT1} min={-100} max={1000} color={t1 > t0 ? 'orange' : 'cyan'} />
                        <InputField label="Initial Length (L0) in mm" value={initialLength} onChange={setInitialLength} />
                    </div>
                </div>
            </div>

            {/* Abartılmış Mikro-Ölçek Görselleştirici (Magnetic Feature) */}
            <div className={`p-6 bg-white/[0.01] border ${result.dangerLevel === 'Critical' ? 'border-red-500/50 shadow-[0_0_30px_rgba(239,68,68,0.2)]' : 'border-white/5'} rounded-xl relative overflow-hidden transition-all duration-500`}>
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.02] to-transparent pointer-events-none" />

                <div className="flex justify-between items-end mb-8 relative z-10">
                    <div>
                        <h4 className="text-[10px] font-bold text-gray-500 tracking-[0.2em] uppercase mb-1">Thermodynamic Shift</h4>
                        <div className="flex items-baseline gap-2">
                            <span className={`text-5xl font-black font-mono tracking-tighter ${result.isExpanding ? 'text-red-400 drop-shadow-[0_0_15px_rgba(248,113,113,0.5)]' : 'text-blue-400 drop-shadow-[0_0_15px_rgba(96,165,250,0.5)]'}`}>
                                {result.deltaT > 0 ? '+' : ''}{result.deltaL}
                            </span>
                            <span className="text-xl font-bold text-gray-500">mm</span>
                        </div>
                    </div>
                    <div className="text-right">
                        <p className="text-[10px] font-bold text-gray-500 tracking-[0.2em] uppercase mb-1">Final Dimension</p>
                        <p className="text-2xl font-black text-white font-mono">{result.finalLength} mm</p>
                    </div>
                </div>

                {/* Exaggerated Bar Graphic */}
                <div className="relative h-16 w-full flex items-center justify-center pt-2">
                    <div className="w-full max-w-[80%] flex items-center drop-shadow-2xl">
                        {/* Base L0 Bar */}
                        <div
                            className="h-8 bg-gray-600/50 backdrop-blur-sm border-y border-l border-white/20 relative"
                            style={{ width: `${barBasePct}%`, transition: 'width 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275)' }}
                        >
                            <span className="absolute -top-6 left-0 text-[10px] font-mono text-gray-500">0</span>
                            <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] font-black text-gray-600 tracking-widest uppercase">L0: {initialLength}mm</span>
                        </div>

                        {/* Delta Bar (Expanding or Contracting representation) */}
                        {visualDelta !== 0 && (
                            <div
                                className={`h-8 border-y border-r relative ${result.isExpanding ? 'bg-red-500/80 border-red-400 shadow-[0_0_20px_rgba(239,68,68,0.8)]' : 'bg-blue-500/80 border-blue-400 shadow-[0_0_20px_rgba(59,130,246,0.8)]'}`}
                                style={{ width: `${Math.abs(visualDelta)}%`, transition: 'width 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275)' }}
                            >
                                <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,transparent,transparent_5px,rgba(255,255,255,0.2)_5px,rgba(255,255,255,0.2)_10px)]" />
                                <span className={`absolute -top-6 right-0 text-[10px] font-black font-mono ${result.isExpanding ? 'text-red-400' : 'text-blue-400'}`}>
                                    {result.deltaT > 0 ? '+' : ''}{result.deltaL}
                                </span>
                            </div>
                        )}
                        {!result.isExpanding && visualDelta !== 0 && (
                            // Dashed line showing where it used to be if it contracted
                            <div className="h-8 border-y border-r border-dashed border-gray-600/50" style={{ width: `${Math.abs(visualDelta)}%`, transition: 'all 0.5s' }} />
                        )}
                    </div>
                </div>

                {/* Warning System */}
                {result.dangerLevel !== 'Safe' && (
                    <div className={`mt-8 p-3 rounded-lg border flex items-start gap-3 ${result.dangerLevel === 'Critical' ? 'bg-red-500/10 border-red-500/50 text-red-400' : 'bg-amber-500/10 border-amber-500/50 text-amber-400'}`}>
                        <AlertCircle className="mt-0.5 shrink-0" size={16} />
                        <div>
                            <p className="text-[10px] font-black uppercase tracking-widest mb-1">{result.dangerLevel} THRESHOLD REACHED</p>
                            <p className="text-xs">{result.dangerMsg}</p>
                        </div>
                    </div>
                )}
            </div>

            {/* Engineering Metrics Data Grid */}
            <div className="grid grid-cols-3 gap-2 mt-2">
                <MetricBox label="Temp Delta (ΔT)" value={`${result.deltaT > 0 ? '+' : ''}${result.deltaT}°C`} />
                <MetricBox label="Thermal Strain" value={`${result.strain}%`} />
                <MetricBox label="Melting Point" value={`~${meltingPoint}°C`} color={t1 > meltingPoint ? 'red' : undefined} />
            </div>

        </div>
    );
}

function ThermalSlider({ label, value, onChange, min, max, color }: any) {
    // Generate a contextual heat gradient
    let gradient = '';
    if (color === 'cyan') gradient = 'linear-gradient(90deg, #1e3a8a 0%, #06b6d4 100%)';
    else if (color === 'orange') gradient = 'linear-gradient(90deg, #b45309 0%, #ef4444 100%)';
    else gradient = 'bg-gray-700';

    return (
        <div>
            <div className="flex justify-between items-baseline mb-1">
                <label className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">{label}</label>
                <div className="flex items-center bg-black/40 border border-white/10 rounded overflow-hidden">
                    <input type="number" value={value} onChange={e => onChange(Number(e.target.value))} className="w-16 px-2 py-1 bg-transparent text-xs font-mono font-bold text-white outline-none text-right" />
                    <span className="px-2 text-[9px] font-bold text-gray-500 bg-white/[0.05]">°C</span>
                </div>
            </div>
            <input
                type="range" min={min} max={max} value={value} onChange={e => onChange(Number(e.target.value))}
                className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
                style={{ background: gradient }}
            />
        </div>
    );
}

function InputField({ label, value, onChange }: any) {
    return (
        <div className="mt-2 text-right border-t border-white/10 pt-2">
            <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">{label}</label>
            <input type="number" step="any" value={value} onChange={e => onChange(Number(e.target.value))}
                className="w-full text-right px-3 py-2 bg-black/40 border border-white/10 rounded-lg text-sm font-mono font-bold text-white focus:border-cyan-500 outline-none transition-colors"
                onFocus={(e) => e.target.select()}
            />
        </div>
    );
}

function MetricBox({ label, value, color }: { label: string, value: string, color?: 'red' | 'cyan' | 'amber' }) {
    return (
        <div className={`p-3 rounded-lg border bg-black/40 text-center flex flex-col justify-center ${color === 'red' ? 'border-red-500/50 text-red-400' :
                color === 'cyan' ? 'border-cyan-500/50 text-cyan-400' :
                    color === 'amber' ? 'border-amber-500/50 text-amber-400' :
                        'border-white/5 text-gray-300'
            }`}>
            <span className="text-[8px] font-bold uppercase tracking-widest text-gray-500 mb-1">{label}</span>
            <span className="text-sm font-black font-mono">{value}</span>
        </div>
    );
}
